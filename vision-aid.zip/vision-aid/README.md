# VisionAid: Navigation Assistant for Visually Impaired

A web app that uses camera-based object detection to assist visually impaired users in navigating their environment. It detects objects, estimates distances, and provides audio feedback.

## Setup

1. **Install Node.js**: Download and install from [nodejs.org](https://nodejs.org).
2. **Extract the Project**: Unzip the `vision-aid.zip` file.
3. **Install Dependencies**:
   - Open a terminal in the `vision-aid` folder.
   - Run: `npm install`
4. **Build Tailwind CSS**:
   - Run: `npm run build:css`
   - This generates `src/output.css`.
5. **Serve the App**:
   - Install a local server: `npm install -g http-server`
   - Run: `http-server`
   - Open the displayed URL (e.g., `http://127.0.0.1:8080`) in Chrome or Safari.
6. **Test**:
   - Grant camera permission.
   - Test in a well-lit room with objects (e.g., chair, table) 1–3 meters away.
   - Check the browser console (F12 > Console) for detection logs.

## Requirements
- Chrome or Safari browser (smartphone recommended).
- HTTPS or localhost for camera access.
- Well-lit environment for accurate object detection.

## Troubleshooting
- **No detections**: Ensure good lighting, hold camera 1–3 meters from objects, and check console logs.
- **Lag**: Increase `FRAME_RATE` in `index.html` (e.g., to 1000 for 1 FPS).
- **Errors**: Share console logs with the developer.

## License
MIT License
